<?php
require 'flight/Flight.php';
require_once 'medoo.php';
require_once 'captcha/autoload.php';

$database = new medoo([
	'database_type'	=>'mysql',
	'database_name'	=>'elektrop_urlshortener',
	'server'		=>'localhost',
	// Mode Localhost / development
	'username'		=>'root',
	'password'		=>'',
	// Mode deployment
	 // 'username'		=>'elektrop_rahman',
	 // 'password'		=>'semester4',
	'charset'		=>'utf8'
	]);

$table_email		= 'university_war';
$table_universitas	= 'university_list';
$table_chat         = 'university_chat_war';
$period				= 1;

$from				= "University_War@elektropal.com"; // this is the sender's Email address
$first_name			= "tryan";
$last_name			= "aditya";
$subject			= "Form submission";
$headers			= "From:" . $from;

$view_path 			= "views/";

$recaptcha_key      = '6Lfu3BMTAAAAALkBs2lwd2cQC9Uv48mAqKu2bdmI';
$recaptcha_secret   = '6Lfu3BMTAAAAAMYW_2sF_ocs3ZALJXhQvp01e-LG';
$recaptcha_lang     = 'id';
$recaptcha			= new \ReCaptcha\ReCaptcha($recaptcha_secret);

Flight::set('flight.base_url','/elektropal_univwar');
// Flight::set('flight.base_url','/univwar');
Flight::set('my_base_url','http://localhost/elektropal_univwar');
// Flight::set('my_base_url','http://elektropal.com/univwar');

function str_random($length = 16){
	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	return substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
}




Flight::route('/', function() use($view_path,$recaptcha_key,$recaptcha_secret,$recaptcha_lang){
	session_start();
	$viewdata['view_path']			= $view_path;
	$viewdata['recaptcha_key']		= $recaptcha_key;
	$viewdata['recaptcha_secret']	= $recaptcha_secret;
	$viewdata['recaptcha_lang']     = $recaptcha_lang;
	Flight::render('landing.php',$viewdata);
});

Flight::route('/progress',function() use($database,$table_email,$table_universitas,$view_path){
	$verified		= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 1 AND isverified_pribadi = 1 GROUP BY kode_univ")->fetchAll();	
	$not_verified	= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 0 OR isverified_pribadi = 0 GROUP BY kode_univ")->fetchAll();
	$universities   = $database->select($table_universitas,'*');
	
	// To simplify we create mapping from id to count

	foreach ($verified as $v) {
		$mapping_verified[$v['kode_univ']] = $v['count(*)'];
	}
	$mapping_not_verified = array();
	foreach ($not_verified as $nv) {
		$mapping_not_verified[$nv['kode_univ']] = $nv['count(*)'];
	}

	
	echo "<br>";
	for ($i=0; $i < count($universities); $i++) { 
		$university = $universities[$i];
		$unverified = array_key_exists($university['id'], $mapping_not_verified) ? $mapping_not_verified[$university['id']] : 0;
		echo $i . ' ' . $university['nama_univ'] . ' &nbsp;' . $mapping_verified[$university['id']] . '&nbsp' . $unverified;
		echo "<br>";
	}
	
	echo "this page is for progress";
});


Flight::route('/result',function() use($database,$table_email,$table_universitas,$view_path){
	session_start();
	$viewdata['view_path'] = $view_path;
	Flight::render('result.php',$viewdata);
});

Flight::route('POST /submit',function() use($database,$table_email,$table_universitas,$period,$first_name,$last_name,$subject,$headers,$recaptcha_key,$recaptcha_secret,$recaptcha,$view_path,$recaptcha_lang){
	try{
		$status_code	= 200;
		$response		= "OK";
		$result			= null;
		$messages		= "Successfully submiting email";

		$cookie_name	 = "epal_chat";
		$cookie_value    =  strtolower($_POST['email_pribadi'])."_". strtolower($_POST['email_univ']);
		setcookie($cookie_name, $cookie_value, time()+(86400 * 14),"/");
		// 0. Check the recaptcha if invalid, throw exception
		if(isset($_POST['g-recaptcha-response'])){
			$resp		= $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

			if($resp->isSuccess()){
				$personal_email			= strtolower($_POST['email_pribadi']);
				$university_email		= strtolower($_POST['email_univ']);
				$email_pribadi			= $personal_email;
				$email_univ				= $university_email;
				$isvalid_email_pribadi	= preg_match("/[\w-]+@([\w-]+\.)+[\w-]+/", $personal_email);
				$isvalid_email_univ		= preg_match("/[\w-]+@([\w-]+\.)+[\w-]+/", $personal_email);
				if(!($isvalid_email_univ==FALSE || $isvalid_email_pribadi == FALSE)){
					// 1. Check the email is it used before ?
					$existance = $database->select($table_email,[
							"email_univ"
						],[
						"OR"=>[
							"email_univ"	=> $university_email,
							"email_pribadi"	=> $personal_email
						]
					]);
					

					if(count($existance)==0){
						// 2.a Generate random string make sure that the string is unique
						do{
							$token_univ		= str_random(30);
							$token_pribadi	= str_random(30);
							$datas 			= $database->select($table_email,[
									"email_univ"
								],[
									"OR"=>[
										"token_univ"	=>$token_univ,
										"token_pribadi"	=>$token_pribadi
									]
								]);
						}while(count($datas)>0);

						// 2.b Send the email
						$messagepribadi	= $first_name . " " . $last_name . " Klik untuk mengkonfirmasi:" . "\n\n" . "ini isinya".Flight::get('my_base_url')."/confirm/p/".$email_pribadi."/".$token_pribadi;
						$messageuniv	= $first_name . " " . $last_name . " Klik untuk mengkonfirmasi:" . "\n\n" . "ini isinya".Flight::get('my_base_url')."/confirm/u".$email_univ."/".$token_univ;
						mail($email_pribadi,$subject,$messagepribadi,$headers);
						mail($email_univ,$subject,$messageuniv,$headers);

						$matches   = array();
						preg_match('/[A-z0-9]+(?=[\.][a][c][\.][i][d])/', $email_univ,$matches);
						$shortname = $matches[0];
						$ids = $database->select($table_universitas,[
								'id'
							],[
								"shortname"=>$shortname
						]);

						if(count($ids)>0){
							// 2.d Then insert to database
							$database->insert($table_email,[
								'email_pribadi'			=> $personal_email,
								'email_univ'			=> $university_email,
								'token_pribadi'			=> $token_pribadi,
								'token_univ'			=> $token_univ,
								'isverified_pribadi'	=> 0,
								'isverified_univ'		=> 0,
								'period'				=> $period,
								'kode_univ'				=> $ids[0]['id']
							]); 

							// 2.e Echo message
							$message				= "Success adding to database";
							$viewdata['view_path']	= $view_path;
							$viewdata['message']	= $message;
							$viewdata['error']		= false;
							Flight::render('result.php',$viewdata);
						}else{
							$message						= "Please contact the administrator, your university is not yet listed in our data";
							$viewdata['view_path']			= $view_path;
							$viewdata['message']			= $message;
							$viewdata['error']				= true;
							$viewdata['recaptcha_lang']		= 'id';
							$viewdata['recaptcha_key']		= $recaptcha_key;
							$viewdata['recaptcha_secret']	= $recaptcha_secret;
							$viewdata['recaptcha_lang']		= $recaptcha_lang;
							Flight::render('landing.php',$viewdata);
						}
					}else{
						// 3.a if Exist, then echo invalid message
						$message						= "One of the Email is already in used";
						$viewdata['view_path']			= $view_path;
						$viewdata['message']			= $message;
						$viewdata['error']				= true;
						$viewdata['recaptcha_key']		= $recaptcha_key;
						$viewdata['recaptcha_secret']	= $recaptcha_secret;
						$viewdata['recaptcha_lang']		= $recaptcha_lang;
						Flight::render('landing.php',$viewdata);
					}
				}else{
					$message						= "Invalid email format";
					$viewdata['view_path']			= $view_path;
					$viewdata['message']			= $message;
					$viewdata['error']				= true;
					$viewdata['recaptcha_key']		= $recaptcha_key;
					$viewdata['recaptcha_secret']	= $recaptcha_secret;
					$viewdata['recaptcha_lang']		= $recaptcha_lang;
					Flight::render('landing.php',$viewdata);
				}
			}else{
				$message						= $resp->getErrorCodes();
				$viewdata['view_path']			= $view_path;
				$viewdata['message']			= $message;
				$viewdata['error']				= true;
				$viewdata['recaptcha_key']		= $recaptcha_key;
				$viewdata['recaptcha_secret']	= $recaptcha_secret;
				$viewdata['recaptcha_lang']		= $recaptcha_lang;
				Flight::render('landing.php',$viewdata);
			}
		}else{
			// $viewdata['view_path'] = $view_path;
			// $viewdata['message'] = "You Failed to solve the captcha";
			// $viewdata['error'] = true;
			// Flight::render('result.php',$viewdata);
			$message						= "You failed to solve ReCaptcha";
			$viewdata['view_path']			= $view_path;
			$viewdata['message']			= $message;
			$viewdata['error']				= true;
			$viewdata['recaptcha_key']		= $recaptcha_key;
			$viewdata['recaptcha_secret']	= $recaptcha_secret;
			$viewdata['recaptcha_lang']		= $recaptcha_lang;
			Flight::render('landing.php',$viewdata);
		}
		// $returndata = array(
		// 	'status_code'	=> $status_code,
		// 	'response'		=> $response,
		// 	'message'		=> $message,
		// 	'result'		=> $result,
		// );
		// Flight::json($returndata);
	}catch(Exception $e){
		Flight::redirect('/');
	}
});

Flight::route('/confirm/u/@email/@token',function($email,$token) use($database,$table_email){
	$affected = $database->update($table_email,[
			'isverified_univ'=>1
		],[
			"AND"=>[
				"email_univ" => $email,
				"token_univ" => $token,
			]
		]);

	if($affected==0){
		echo "Invalid confirmation link";
	}else{
		echo "Confirmation link verified";
	}
});



Flight::route('/confirm/p/@email/@token',function($email,$token) use($database,$table_email){
	$affected = $database->update($table_email,[
			'isverified_pribadi'=>1
		],[
			"AND"=>[
				"email_pribadi" => $email,
				"token_pribadi" => $token,
			]
		]);

	if($affected==0){
		echo "Invalid confirmation link";
	}else{
		echo "Confirmation link verified";
	}
});


// ===================================== API LIST ============================================
// 
// ===========================================================================================

Flight::route('/api/result',function() use($database,$table_email,$table_universitas,$view_path){
	$returndata		= array();
	$response		= "OK";
	$status_code	= 200;
	$result			= null;
	$message		= null;

	// 1. Ambil seluruh data 
	$verified			= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 1 AND isverified_pribadi = 1 GROUP BY kode_univ")->fetchAll();	
	$verified_pribadi	= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 0 AND isverified_pribadi = 1 GROUP BY kode_univ")->fetchAll();
	$verified_univ		= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 0 AND isverified_pribadi = 1 GROUP BY kode_univ")->fetchAll();
	$not_verified		= $database->query("SELECT kode_univ,count(*) from ".$table_email." WHERE isverified_univ = 0 OR isverified_pribadi = 0 GROUP BY kode_univ")->fetchAll();
	$universities		= $database->select($table_universitas,'*');
	
	// 2. Format ulang data yang diretrieve agar lebih mudah dihasilkan.
	$mapping_verified = array();
	foreach ($verified as $v) {
		$mapping_verified[$v['kode_univ']] = $v['count(*)'];
	}
	$mapping_verified_pribadi = array();
	foreach ($verified_pribadi as $vp) {
		$mapping_verified_pribadi[$vp['kode_univ']] = $vp['count(*)'];
	}
	$mapping_verified_univ = array();
	foreach ($verified_univ as $vu) {
		$mapping_verified_univ[$vu['kode_univ']] = $vu['count(*)'];
	}
	$mapping_not_verified = array();
	foreach ($not_verified as $nv) {
		$mapping_not_verified[$nv['kode_univ']] = $nv['count(*)'];
	}

	// 3. Format ulang agar sesuai dengan Highcharts
	// 3.a format ulang data untuk Xaxis
	$categories = array();
	foreach ($universities as $university) {
		$_categories[]			= $university['nama_univ'];
		$_unverified[]			= array_key_exists($university['id'], $mapping_not_verified) ? (int) $mapping_not_verified[$university['id']] : 0;
		$_verified_pribadi[]	= array_key_exists($university['id'], $mapping_verified_pribadi) ? (int) $mapping_verified_pribadi[$university['id']] : 0;
		$_verified_univ[]		= array_key_exists($university['id'], $mapping_verified_univ) ? (int) $mapping_verified_univ[$university['id']] : 0;
		$_verified[]			= array_key_exists($university['id'], $mapping_verified) ? (int) $mapping_verified[$university['id']] : 0;
	}

	$series = [
		[
			'name'=>'Unverified',
			'data'=>$_unverified
		],
		[
			'name'=>'verified email pribadi',
			'data'=>$_verified_pribadi
		],
		[
			'name'=>'verified email univ',
			'data'=>$_verified_univ
		],
		[
			'name'=>'verified',
			'data'=>$_verified
		],
	];

	$result['xaxis']['categories'] = $_categories;
	$result['series']=$series;
	
	


	$returndata = array(
		'response'		=> $response,
		'status_code'	=> $status_code,
		'result'		=> $result,
		'message'		=> $message
	);
	Flight::json($returndata);
});

Flight::route('/elektropal_admin',function(){

});

Flight::route('/chat',function(){
	session_start();
	if(isset($_SESSION['leh_uga']) && ($_SESSION['leh_uga'])){
		$view_data = null;
		$view_data['asset_path'] = Flight::get('my_base_url').'/views/admin';
		Flight::render('admin/sample/chat',$view_data);	
	}else{
		Flight::redirect('/the_login');
		// header('Location: '.Flight::get('flight.base_url').'/the_login');	
	}
});

Flight::route('/email_list',function() use($database,$table_email){
	session_start();
	if(isset($_SESSION['leh_uga']) && ($_SESSION['leh_uga'])){
		$view_data					= null;
		$datas						= $database->select($table_email,"*",["ORDER"=>['isverified_pribadi ASC','isverified_univ ASC']]);
		$view_data['datas']			= $datas;
		$view_data['asset_path']	= Flight::get('my_base_url').'/views/admin';
		Flight::render('admin/sample/email_list',$view_data);	
	}else{
		Flight::redirect('/the_login');
		// header('Location: '.Flight::get('flight.base_url').'/the_login');	
	}
});

Flight::route('/university_list',function() use($database,$table_universitas){
	session_start();
	if(isset($_SESSION['leh_uga']) && ($_SESSION['leh_uga'])){
		$view_data					= null;
		$datas						= $database->select($table_universitas,"*");
		$view_data['datas']			= $datas;
		$view_data['adallala']      = "tes aja";
		$view_data['asset_path']	= Flight::get('my_base_url').'/views/admin';
		Flight::render('admin/sample/university_list',$view_data);	
	}else{
		Flight::redirect('/the_login');
		// header('Location: '.Flight::get('flight.base_url').'/the_login');	
	}
});

Flight::route('/change_period',function() use($database,$table_email){
	session_start();
	if(isset($_SESSION['leh_uga']) && ($_SESSION['leh_uga'])){
		$view_data					= null;
		$data						= null;
		/// DO the logic here
		// #################################################################################################
		$view_data['asset_path']	= Flight::get('my_base_url').'/views/admin';
		Flight::render('admin/sample/university_list',$view_data);	
	}else{
		Flight::redirect('/the_login');
		// header('Location: '.Flight::get('flight.base_url').'/the_login');	
	}
});

Flight::route('/the_login',function(){
	session_start();
	$view_data['asset_path']	= Flight::get('my_base_url').'/views/admin';
	Flight::render('admin/sample/login',$view_data);
});

Flight::route('/tes',function(){
	session_start();
	try{
		$view_data = null;
		//var_dump($_POST['name']);
		if(($_POST['name']=="e_pal")&&($_POST['tes']=="semester4")){
			$_SESSION['leh_uga'] = true;
			//header('Location: '.Flight::get('flight.base_url').'/chat');
			Flight::redirect('/chat');
		}else{
			Flight::redirect('the_login');
			//header('Location: '.Flight::get('flight.base_url').'/the_login');
		}
	}catch(Exception $e){
		Flight::redirect('the_login');
	}
	
});

Flight::route('/the_logout',function(){
	session_start();
	session_destroy();
	Flight::redirect('/the_login');
	//header('Location: '.Flight::get('flight.base_url').'/the_login');
});

Flight::route('/delete/@email_pribadi/@email_univ',function($email_pribadi,$email_univ) use($database,$table_email){
	session_start();
	if(isset($_SESSION['leh_uga']) && ($_SESSION['leh_uga'])){
		$database->delete($table_email,[
			"AND"=>[
				'email_univ'=>$email_univ,
				'email_pribadi'=>$email_pribadi
			]
		]);
		Flight::redirect('/email_list');
	}else{
		Flight::redirect('/the_login');
		// header('Location: '.Flight::get('flight.base_url').'/the_login');	
	}
});

Flight::route('/sandbox',function(){
	session_start();
	$view_data = null;
	Flight::render('sandbox.php',$view_data);
});




Flight::start();
?>
